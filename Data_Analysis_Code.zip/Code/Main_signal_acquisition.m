clear
close all
clc

load('..\Signal_Acquisition\DATA_Beads.mat')

signal_filt_long=[];

font_sz=18;
legend_sz=12;

for iii=98+14
% for iii=98:numel(signal_filt_save)
        signal_filt_long=[signal_filt_long; signal_filt_save{iii}] ;

        xxx=lowpass(signal_filt_save{iii},1e-4);
        
      
        figure()
        plot(1/40000:1/40000:1 ,         signal_unfilt_save{iii}-min(signal_unfilt_save{iii}), 'Color', [0.1 , 0.1, 0.8])
        xlabel('Time [s]', 'FontSize',font_sz)
        ylabel('Photodetector raw signal [V]', 'FontSize',font_sz)
        % legend('Measured signal', 'Detected events')
        % ylim([0, 0.])
        
        signal4fig=xxx(20:end-20)-min(xxx(20:end-20));
        time_vect=(20/numel(xxx)):1/numel(xxx):1-20/numel(xxx);
        [peaks, locs]= findpeaks(signal4fig, "MinPeakDistance",35, "MinPeakHeight",0.02);
            numel(locs)

        figure()
        plot(time_vect, signal4fig, 'Color', [0.1 , 0.1, 0.8])
        hold on
        scatter(time_vect(locs), peaks, 'r' )
        xlabel('Time [s]', 'FontSize',font_sz)
        ylabel('Filtered signal [V]', 'FontSize',font_sz)
        legend('Signal', 'Detected events', 'FontSize',legend_sz)
        ylim([0, 0.2])
        
        

        pause()

end

figure()
plot(signal_filt_long)

xxx=lowpass(signal_filt_long,1e-4);

signal_filt_long_filt=xxx(20:(numel(xxx)-20));


figure()
plot(signal_filt_long_filt)
