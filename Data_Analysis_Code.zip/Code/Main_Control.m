clear
close all
clc

filename_list{1}='01.03.23_TestFeedback_High_TFR.mat'; discard_ind{1}=[1:10, 132:137, 402:406]; conc1_ind{1}=[11:131,  407:533]; conc2_ind{1}=138:401; 
filename_list{2}='13.03.23_Feedback_Low_TFR.mat'; discard_ind{2}=[62:67, 187:194]; conc1_ind{2}=[1:61,  195:247]; conc2_ind{2}=68:186;

foldername='..\Only_Cell_Counter\Feedback_Controller\';

regulation_error=[];

for iii=1:2
    filename=filename_list{iii};

    name=[foldername filename];

    load(name)

    % figure()
    % plot(cell_setpoint)
    % hold on
    % plot(n_events,'*')
    % 
    % figure()
    % plot(total_flow_rate)
    % hold on
    % plot(main_flow_rate)
    % plot(suggested_flow_rate_LOG)

    figure()
    plot(cell_setpoint./total_flow_rate*60)
    hold on
    plot(n_events./total_flow_rate*60,'*')
    xlabel('Time')
    ylabel('Concentration')

    regulation_error_all=((n_events-cell_setpoint)./total_flow_rate*60*1000)...
                          ./(cell_setpoint./total_flow_rate*60*1000);

    error(iii*2-1)=mean(regulation_error_all(conc1_ind{iii}));
    error(iii*2)=mean(regulation_error_all(conc2_ind{iii}));


    discard=zeros(size(regulation_error_all));
    discard(discard_ind{iii})=true;

    regulation_error=[regulation_error regulation_error_all(~discard)];

end

mean(regulation_error)
std(regulation_error)

figure()
plot(regulation_error)

