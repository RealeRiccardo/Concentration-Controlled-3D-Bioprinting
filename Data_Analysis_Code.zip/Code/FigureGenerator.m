close all

%%
clear
clc

font_sz=18;
legend_sz=12;

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % GRADIENT
Exp.Type='Gradient\';

% % % BUILD FOLDER PATH
Exp.mainfolder='..\Printing\';
subfolder='Confocal\';
Exp.pathname=[ Exp.mainfolder Exp.Type subfolder];

% % % LOAD MEASUREMENTS PARAMETERS
Exp=Load_Exp_Param(Exp);

% % % LOAD MOSAIC IMAGE
[Exp, total_image]=Load_Mosaic(Exp);
load([Exp.mainfolder Exp.Type 'AppData.mat'])

total_image_filt = medfilt2(total_image);

% % % % BINARIZE MOSAIC IMAGE
bin_I=imbinarize(total_image_filt,  Exp.Bin_Threshold);

% % % SELECT REGIONS WITH AREA GREATER THAN THRESHOLD
props=regionprops( bin_I,'all');
n_regions=numel(props);
cell_IND=false(n_regions,1);
for zzz=1:n_regions
    if props(zzz).Area>Exp.Area_Threshold
        cell_IND(zzz)=1;
    end
end

% % % COORDINATES OF CELLS CENTROID
ind_coor=extractfield(props(cell_IND), 'Centroid');
x_coor=ind_coor(1:2:(numel(ind_coor)-1));
y_coor=ind_coor(2:2:numel(ind_coor));

N_bins=7;
BinWidth=floor(size(bin_I,2)/N_bins)-1;
BinEdges=1:BinWidth:size(bin_I,2);
bin_counts = histcounts(x_coor, BinEdges); 
bin_counts_scaled = bin_counts ./(BinWidth*Exp.pixel2um*1e-3*Exp.Image_size*Exp.n_stack*0.015) ;
bin_edges_scaled  = BinEdges*Exp.pixel2um*1e-3;

cell_conc_app=n_events(Exp.AppInd)*60/Total_flow_rate(1);

% final_image(:,:,1)=zeros(size(bin_I(1200:2005,:)));
% final_image(:,:,2)=bin_I(1200:2005,:);
% final_image(:,:,3)=zeros(size(bin_I(1200:2005,:)));

inds1=[1:1024, 1100:2048, 2200:2800, 3200:4096];
inds2=1:5120;
final_image(:,:,1)=zeros(size(bin_I( inds1, inds2)));
final_image(:,:,2)=bin_I(inds1,inds2);
final_image(:,:,3)=zeros(size(bin_I(inds1,inds2)));

f=figure()
imshow(final_image, [], 'XData', [0 size(final_image,2)*Exp.pixel2um*1e-3 ], 'YData', [ 0 size(final_image,1)*Exp.pixel2um*1e-3])
axis('on', 'image');
set(gca,'ytick',[0,1,2,3,4])
box off
xlabel('Construct Height (z-axis) [mm]','FontSize',font_sz)
ylabel('Construct Width (y-axis) [mm]','FontSize',font_sz)
exportgraphics(f,"Gradient_Image.png")

stepstep=bin_edges_scaled(end)/numel(cell_setpoint(Exp.AppInd));
figure()
histogram('BinEdges',bin_edges_scaled-(bin_edges_scaled(1)),'BinCounts',bin_counts_scaled,'FaceColor',[0.1, 0.8, 0.1])
hold on
plot(0:stepstep:bin_edges_scaled(end)-stepstep, cell_setpoint(Exp.AppInd) *60/Total_flow_rate(1)/2, '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',2 )
xlabel('Construct Height [mm]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
legend('Measured concentration', 'Target concentration','FontSize',legend_sz)
xlim([-0.1, bin_edges_scaled(end)+0.1])
ylim([0,400])

figure()
plot(1:numel(Exp.AppInd),cell_conc_app,'.r','MarkerSize',10)
hold on
plot(1:numel(Exp.AppInd),cell_setpoint(Exp.AppInd) *60/Total_flow_rate(1), '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',2 )
xlabel('Time [s]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
legend('Measured concentration', 'Concentration setpoint','FontSize',legend_sz)
ylim([0,800])
xlim([1,numel(Exp.AppInd)])

setpoint=cell_setpoint(Exp.AppInd) *60/Total_flow_rate(1);

RMS_diff=rms((cell_conc_app(1:175)-setpoint(1:175))./setpoint(1:175));




% % % figure()
% % % plot(Pump1FlowRateulmin(Exp.AppInd))
% % % hold on
% % % yline(Total_flow_rate(1), '--r')
% % % xlabel('Time [s]')
% % % ylabel('Flow rate [{\mul}/min]')
% % % legend('Sample Flow rate', 'Total Flow rate')

%%
clear
clc

font_sz=18;
legend_sz=12;

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % CONSTANT
Exp.Type='Constant\';

% % % BUILD FOLDER PATH
Exp.mainfolder='..\Printing\';
subfolder='Confocal\';
Exp.pathname=[ Exp.mainfolder Exp.Type subfolder];

% % % LOAD MEASUREMENTS PARAMETERS
Exp=Load_Exp_Param(Exp);

% % % LOAD MOSAIC IMAGE
[Exp, total_image]=Load_Mosaic(Exp);
load([Exp.mainfolder Exp.Type 'AppData.mat'])

total_image_filt = medfilt2(total_image);

% % % % BINARIZE MOSAIC IMAGE
bin_I=imbinarize(total_image_filt,  Exp.Bin_Threshold);

% % % SELECT REGIONS WITH AREA GREATER THAN THRESHOLD
props=regionprops( bin_I,'all');
n_regions=numel(props);
cell_IND=false(n_regions,1);
for zzz=1:n_regions
    if props(zzz).Area>Exp.Area_Threshold
        cell_IND(zzz)=1;
    end
end

% % % COORDINATES OF CELLS CENTROID
ind_coor=extractfield(props(cell_IND), 'Centroid');
x_coor=ind_coor(1:2:(numel(ind_coor)-1));
y_coor=ind_coor(2:2:numel(ind_coor));

N_bins=7;
BinWidth=floor(size(bin_I,2)/N_bins)-1;
BinEdges=1:BinWidth:size(bin_I,2);
bin_counts = histcounts(x_coor, BinEdges); 
bin_counts_scaled = bin_counts ./(BinWidth*Exp.pixel2um*1e-3*Exp.Image_size*Exp.n_stack*0.015) ;
bin_edges_scaled  = BinEdges*Exp.pixel2um*1e-3;

cell_conc_app=n_events(Exp.AppInd)*60/Total_flow_rate(1);

% final_image(:,:,1)=zeros(size(bin_I(1:806,:)));
% final_image(:,:,2)=bin_I(1:806,:);
% final_image(:,:,3)=zeros(size(bin_I(1:806,:)));

final_image(:,:,1)=zeros(size(bin_I));
final_image(:,:,2)=bin_I;
final_image(:,:,3)=zeros(size(bin_I));


f=figure()
imshow(final_image, [], 'XData', [0 size(final_image,2)*Exp.pixel2um*1e-3 ], 'YData', [ 0 size(final_image,1)*Exp.pixel2um*1e-3])
axis('on', 'image');
set(gca,'ytick',[0,1,2,3,4])
box off
xlabel('Construct Height (z-axis) [mm]','FontSize',font_sz)
ylabel('Construct Width (y-axis) [mm]','FontSize',font_sz)
exportgraphics(f,"Constant_Image.png")

stepstep=bin_edges_scaled(end)/numel(cell_setpoint(Exp.AppInd));
figure()
histogram('BinEdges',bin_edges_scaled-(bin_edges_scaled(1)),'BinCounts',bin_counts_scaled,'FaceColor',[0.1, 0.8, 0.1])
hold on
plot(0:stepstep:bin_edges_scaled(end)-stepstep, cell_setpoint(Exp.AppInd) *60/Total_flow_rate(1)/2, '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',2 )
xlabel('Construct Height [mm]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
legend('Measured concentration', 'Target concentration','FontSize',legend_sz)
xlim([-0.1, bin_edges_scaled(end)+0.1])
ylim([0,400])

figure()
plot(1:numel(Exp.AppInd),cell_conc_app,'.r','MarkerSize',10)
hold on
plot(cell_setpoint(Exp.AppInd) *60/Total_flow_rate(1), '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',2 )
xlabel('Time [s]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
legend('Measured concentration', 'Concentration setpoint','FontSize',legend_sz,'Location', 'SE')
ylim([0,800])
xlim([1,numel(Exp.AppInd)])

mean_conc=mean(cell_conc_app);
std_conc=std(cell_conc_app);
disp([Exp.Type ' control unit average conncentration:'])
disp([num2str(mean_conc) ' +/- ' num2str(std_conc)])

mean_confocal=mean(bin_counts_scaled);
std_confocal=std(bin_counts_scaled);
disp([Exp.Type ' printing unit average conncentration:'])
disp([num2str(mean_confocal) ' +/- ' num2str(std_confocal)])




% % % figure()
% % % plot(Pump1FlowRateulmin(Exp.AppInd))
% % % hold on
% % % yline(Total_flow_rate(1), '--r')
% % % xlabel('Time [s]')
% % % ylabel('Flow rate [{\mul}/min]')
% % % legend('Sample Flow rate', 'Total Flow rate')

%%

clear
clc

font_sz=18;
legend_sz=12;

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % CONSTANT
Exp.Type='Sandwich_UD\';

% % % BUILD FOLDER PATH
Exp.mainfolder='..\Printing\';
subfolder='Confocal\';
Exp.pathname=[ Exp.mainfolder Exp.Type subfolder];

% % % LOAD MEASUREMENTS PARAMETERS
Exp=Load_Exp_Param(Exp);

% % % LOAD MOSAIC IMAGE
[Exp, total_image]=Load_Mosaic(Exp);
load([Exp.mainfolder Exp.Type 'AppData.mat'])

total_image_filt = medfilt2(total_image);

% % % % BINARIZE MOSAIC IMAGE
bin_I=imbinarize(total_image_filt,  Exp.Bin_Threshold);

% % % SELECT REGIONS WITH AREA GREATER THAN THRESHOLD
props=regionprops( bin_I,'all');
n_regions=numel(props);
cell_IND=false(n_regions,1);
for zzz=1:n_regions
    if props(zzz).Area>Exp.Area_Threshold
        cell_IND(zzz)=1;
    end
end

% % % COORDINATES OF CELLS CENTROID
ind_coor=extractfield(props(cell_IND), 'Centroid');
x_coor=ind_coor(1:2:(numel(ind_coor)-1));
y_coor=ind_coor(2:2:numel(ind_coor));

N_bins=8;
BinWidth=floor(size(bin_I,2)/N_bins)-1;
BinEdges=1:BinWidth:size(bin_I,2);
% BinEdges=BinWidth/12:BinWidth:size(bin_I,2);
bin_counts = histcounts(x_coor, BinEdges); 
bin_counts_scaled = bin_counts ./(BinWidth*Exp.pixel2um*1e-3*Exp.Image_size*Exp.n_stack*0.015) ;
bin_edges_scaled  = BinEdges*Exp.pixel2um*1e-3;

cell_conc_app=n_events(Exp.AppInd)*60/Total_flow_rate(1);

% figure()
% imshow(bin_I)

% final_image(:,:,1)=zeros(size(bin_I(1200:2006,:)));
% final_image(:,:,2)=bin_I(1200:2006,:);
% final_image(:,:,3)=zeros(size(bin_I(1200:2006,:)));
% f=figure()
% imshow(final_image, [], 'XData', [0 size(final_image,2)*Exp.pixel2um*1e-3 ], 'YData', [ 0 size(final_image,1)*Exp.pixel2um*1e-3])
% axis('on', 'image');
% set(gca,'ytick',[0,1])
% box off
% xlabel('Construct Height (z) [mm]','FontSize',font_sz)
% exportgraphics(f,"SandwichUD_Image.png")


final_image(:,:,1)=zeros(size(bin_I(:,:)));
final_image(:,:,2)=bin_I(:,:);
final_image(:,:,3)=zeros(size(bin_I(:,:)));

f=figure()
imshow(final_image, [], 'XData', [0 size(final_image,2)*Exp.pixel2um*1e-3 ], 'YData', [ 0 size(final_image,1)*Exp.pixel2um*1e-3])
axis('on', 'image');
set(gca,'ytick',[0,1,2,3])
box off
xlabel('Construct Height (z) [mm]','FontSize',font_sz)
ylabel('Construct Width (y) [mm]','FontSize',font_sz)
exportgraphics(f,"SandwichUD_Image.png")

stepstep=bin_edges_scaled(end)/numel(cell_setpoint(Exp.AppInd));
figure()
histogram('BinEdges',bin_edges_scaled-(bin_edges_scaled(1)),'BinCounts',bin_counts_scaled,'FaceColor',[0.1, 0.8, 0.1])
hold on
plot(0:stepstep:bin_edges_scaled(end)-stepstep, cell_setpoint(Exp.AppInd) *60/Total_flow_rate(1)/2, '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',2 )
xlabel('Construct Height [mm]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
legend('Measured concentration', 'Target concentration','FontSize',legend_sz)
xlim([-0.1, bin_edges_scaled(end)+0.1])
ylim([0,400])

figure()
plot(1:numel(Exp.AppInd),cell_conc_app,'.r','MarkerSize',10)
hold on
plot(cell_setpoint(Exp.AppInd) *60/Total_flow_rate(1), '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',2 )
xlabel('Time [s]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
legend('Measured concentration', 'Concentration setpoint','FontSize',legend_sz,'Location', 'NW')
ylim([0,800])
xlim([1,numel(Exp.AppInd)])

% % % figure()
% % % plot(Pump1FlowRateulmin(Exp.AppInd))
% % % hold on
% % % yline(Total_flow_rate(1), '--r')
% % % xlabel('Time [s]')
% % % ylabel('Flow rate [{\mul}/min]')
% % % legend('Sample Flow rate', 'Total Flow rate')



%%

clear
clc

font_sz=18;
legend_sz=12;

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % CONSTANT
Exp.Type='Sandwich_DU\';

% % % BUILD FOLDER PATH
Exp.mainfolder='..\Printing\';
subfolder='Confocal\';
Exp.pathname=[ Exp.mainfolder Exp.Type subfolder];

% % % LOAD MEASUREMENTS PARAMETERS
Exp=Load_Exp_Param(Exp);

% % % LOAD MOSAIC IMAGE
[Exp, total_image]=Load_Mosaic(Exp);
load([Exp.mainfolder Exp.Type 'AppData.mat'])

total_image_filt = medfilt2(total_image);

% % % % BINARIZE MOSAIC IMAGE
bin_I=imbinarize(total_image_filt,  Exp.Bin_Threshold);

% % % SELECT REGIONS WITH AREA GREATER THAN THRESHOLD
props=regionprops( bin_I,'all');
n_regions=numel(props);
cell_IND=false(n_regions,1);
for zzz=1:n_regions
    if props(zzz).Area>Exp.Area_Threshold
        cell_IND(zzz)=1;
    end
end

% % % COORDINATES OF CELLS CENTROID
ind_coor=extractfield(props(cell_IND), 'Centroid');
x_coor=ind_coor(1:2:(numel(ind_coor)-1));
y_coor=ind_coor(2:2:numel(ind_coor));

N_bins=7;
BinWidth=floor(size(bin_I,2)/N_bins)-1;
BinEdges=1:BinWidth:size(bin_I,2);
bin_counts = histcounts(x_coor, BinEdges); 
bin_counts_scaled = bin_counts ./(BinWidth*Exp.pixel2um*1e-3*Exp.Image_size*Exp.n_stack*0.015) ;
bin_edges_scaled  = BinEdges*Exp.pixel2um*1e-3;

cell_conc_app=n_events(Exp.AppInd)*60/Total_flow_rate(1);
% 
% final_image(:,:,1)=zeros(size(bin_I(1:805,:)));
% final_image(:,:,2)=bin_I(1:805,:);
% final_image(:,:,3)=zeros(size(bin_I(1:805,:)));
final_image(:,:,1)=zeros(size(bin_I(:,:)));
final_image(:,:,2)=bin_I(:,:);
final_image(:,:,3)=zeros(size(bin_I(:,:)));

f=figure()
imshow(final_image, [], 'XData', [0 size(final_image,2)*Exp.pixel2um*1e-3 ], 'YData', [ 0 size(final_image,1)*Exp.pixel2um*1e-3])
axis('on', 'image');
set(gca,'ytick',[0,1,2,3])
box off
xlabel('Construct Height (z) [mm]','FontSize',font_sz)
ylabel('Construct Width (y) [mm]','FontSize',font_sz)
exportgraphics(f,"SandwichDU_Image.png")

stepstep=bin_edges_scaled(end)/numel(cell_setpoint(Exp.AppInd));
figure()
histogram('BinEdges',bin_edges_scaled-(bin_edges_scaled(1)),'BinCounts',bin_counts_scaled,'FaceColor',[0.1, 0.8, 0.1])
hold on
plot(0:stepstep:bin_edges_scaled(end)-stepstep, cell_setpoint(Exp.AppInd) *60/Total_flow_rate(1)/2, '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',2 )
xlabel('Construct Height [mm]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
legend('Measured concentration', 'Target concentration','FontSize',legend_sz)
xlim([-0.1, bin_edges_scaled(end)+0.1])
ylim([0,150])

figure()
plot(1:numel(Exp.AppInd),cell_conc_app,'.r','MarkerSize',10)
hold on
plot(cell_setpoint(Exp.AppInd) *60/Total_flow_rate(1), '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',2 )
xlabel('Time [s]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
legend('Measured concentration', 'Concentration setpoint','FontSize',legend_sz,'Location', 'NE')
ylim([0,500])
xlim([1,numel(Exp.AppInd)])

% % % figure()
% % % plot(Pump1FlowRateulmin(Exp.AppInd))
% % % hold on
% % % yline(Total_flow_rate(1), '--r')
% % % xlabel('Time [s]')
% % % ylabel('Flow rate [{\mul}/min]')
% % % legend('Sample Flow rate', 'Total Flow rate')


%%
% RISE TIMES
RT(1)=12; % HLH-HL
RT(2)=05; % HLH-LH
RT(3)=02; % LHL-LH
RT(4)=18; % LHL-HL

meanRT=mean(RT)
stdRT= std(RT)

%%

clear
clc

font_sz=18;
legend_sz=12;

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % CONTROL UNIT ONLY - HIGH TOTAL FLOW RATE
filename='01.03.23_TestFeedback_High_TFR.mat'; 

foldername='..\Only_Cell_Counter\Feedback_Controller\';
name=[foldername filename];
load(name)

ind1=100:180;
ind2=380:430;

figure()
plot(n_events(ind1)./total_flow_rate(ind1)*60,'.r-','MarkerSize',10, 'LineWidth',0.5)
hold on
plot(cell_setpoint(ind1)./total_flow_rate(ind1)*60, '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',2 )
xlabel('Time [s]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
legend('Measured concentration', 'Concentration setpoint','FontSize',legend_sz,'Location', 'SW')
ylim([100,350])
xlim([1, ind1(end)-ind1(1)])

t_grid=1:0.01:numel(ind1);
forfit=n_events(ind1)./total_flow_rate(ind1)*60;
values=Fit_Step_Response(forfit, t_grid);

figure()
hold on
box on
plot(1:numel(ind1),cell_setpoint(ind1)./total_flow_rate(ind1)*60, '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',4 )
plot(t_grid, values,'g-','LineWidth',4)
xlabel('Time [s]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
ylim([140,280])
xlim([1, ind1(end)-ind1(1)])


figure()
plot(n_events(ind2)./total_flow_rate(ind2)*60,'.r-','MarkerSize',10, 'LineWidth',0.5)
hold on
plot(cell_setpoint(ind2)./total_flow_rate(ind2)*60, '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',2 )
xlabel('Time [s]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
legend('Measured concentration', 'Concentration setpoint','FontSize',legend_sz,'Location', 'NW')
ylim([100,350])
xlim([1, ind2(end)-ind2(1)])

t_grid=1:0.01:numel(ind2);
forfit=n_events(ind2)./total_flow_rate(ind2)*60;
values=Fit_Step_Response(forfit, t_grid);

figure()
hold on
box on
plot(1:numel(ind2),cell_setpoint(ind2)./total_flow_rate(ind2)*60, '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',4 )
plot(t_grid, values,'g-','LineWidth',4)
xlabel('Time [s]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
ylim([140,280])
xlim([1, ind2(end)-ind2(1)])


%%

clear
clc

font_sz=18;
legend_sz=12;

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % % CONTROL UNIT ONLY - LOW TOTAL FLOW RATE
filename='13.03.23_Feedback_Low_TFR.mat'; 

foldername='..\Only_Cell_Counter\Feedback_Controller\';
name=[foldername filename];
load(name)


ind1=30:90;
ind2=140:247;

figure()
plot(n_events(ind1)./total_flow_rate(ind1)*60,'.r-','MarkerSize',10, 'LineWidth',0.5)
hold on
plot(cell_setpoint(ind1)./total_flow_rate(ind1)*60, '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',2 )
xlabel('Time [s]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
legend('Measured concentration', 'Concentration setpoint','FontSize',legend_sz,'Location', 'NE')
ylim([80,800])
xlim([1, ind1(end)-ind1(1)])

figure()
plot(n_events(ind2)./total_flow_rate(ind2)*60,'.r-','MarkerSize',10, 'LineWidth',0.5)
hold on
plot(cell_setpoint(ind2)./total_flow_rate(ind2)*60, '--', 'Color', [0.1 , 0.1, 0.8], 'LineWidth',2 )
xlabel('Time [s]','FontSize',font_sz)
ylabel('Cell concentration [cells/{\mul}]','FontSize',font_sz)
legend('Measured concentration', 'Concentration setpoint','FontSize',legend_sz,'Location', 'SE')
ylim([80,800])
xlim([1, ind2(end)-ind2(1)])

