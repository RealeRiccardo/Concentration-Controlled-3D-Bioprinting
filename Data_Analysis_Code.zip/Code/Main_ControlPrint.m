clear
close all
clc

% % % % Exp.Type='Step\';
% % % SELECT EXPERIMENT
% Exp.Type='Constant\';
Exp.Type='Sandwich_UD\';
% Exp.Type='Sandwich_DU\';
% Exp.Type='Gradient\';

% % % BUILD FOLDER PATH
Exp.mainfolder='..\Printing\';
subfolder='Confocal\';
Exp.pathname=[ Exp.mainfolder Exp.Type subfolder];

% % % LOAD MEASUREMENTS PARAMETERS
Exp=Load_Exp_Param(Exp);

% % % LOAD MOSAIC IMAGE
[Exp, total_image]=Load_Mosaic(Exp);

total_image_filt = medfilt2(total_image);

figure()
imagesc(total_image_filt)

% % % % BINARIZE MOSAIC IMAGE
bin_I=imbinarize(total_image_filt,  Exp.Bin_Threshold);

figure()
imshow(bin_I)

% [bin_I, rotation_mask]=rotate_mosaic(bin_I, 35);
% [bin_I, rotation_mask]=rotate_mosaic(bin_I, Exp.Rot_angle);
    

% % % SELECT REGIONS WITH AREA GREATER THAN THRESHOLD
props=regionprops( bin_I,'all');
n_regions=numel(props);
cell_IND=false(n_regions,1);
for zzz=1:n_regions
    if props(zzz).Area>Exp.Area_Threshold
        cell_IND(zzz)=1;
    end
end

% % % COORDINATES OF CELLS CENTROID
ind_coor=extractfield(props(cell_IND), 'Centroid');
x_coor=ind_coor(1:2:(numel(ind_coor)-1));
y_coor=ind_coor(2:2:numel(ind_coor));


% % % % % COMPUTE MOVING AVERAGE OF BINARY MERGED IMAGE
% half_window=100;
% starts=half_window+1;
% ends=size(bin_I,2) - (half_window);
% for kkk=starts:ends
%     sums(kkk)=sum(bin_I(:,(kkk-half_window):(kkk+half_window)))* size(bin_I,1)*100/sum(rotation_mask(:,(kkk-half_window):(kkk+half_window))) ;   
% end
% % sums_scaled=sums./(2*half_window*Exp.pixel2um*1e-3*Exp.Image_size*Exp.n_stack*0.015);
% figure()
% plot(sums)
% hold on
% plot(smooth(sums,2000))

%%

N_bins=20;
BinWidth=floor(size(bin_I,2)/N_bins)-1;

% BinEdges=BinWidth/2:BinWidth:size(bin_I,2);
BinEdges=1:BinWidth:size(bin_I,2);

% % for kkk=1:(numel(BinEdges)-1)
% %     rot_normalization(kkk)=sum(rotation_mask(:,round(BinEdges(kkk)):round(BinEdges(kkk+1))),'all' ) / ( (BinEdges(kkk+1)- BinEdges(kkk))*size(bin_I,1));
% % end

bin_counts = histcounts(x_coor, BinEdges); 
% bin_counts_scaled = bin_counts ./(BinWidth*Exp.pixel2um*1e-3*Exp.Image_size*Exp.n_stack*0.015 *  (rot_normalization/0.5687) );
bin_counts_scaled = bin_counts ./(BinWidth*Exp.pixel2um*1e-3*Exp.Image_size*Exp.n_stack*0.015) ;
bin_edges_scaled  = BinEdges*Exp.pixel2um*1e-3;
% 
% figure()
% imshow(bin_I)

load([Exp.mainfolder Exp.Type 'AppData.mat'])

y_max=max(cell_setpoint(Exp.AppInd)) *60/Total_flow_rate(1)/2  *1.8; 

figure()
histogram('BinEdges',bin_edges_scaled-(bin_edges_scaled(1)),'BinCounts',bin_counts_scaled,'FaceColor',[0.1, 0.8, 0.1])
hold on
yline(cell_setpoint(Exp.AppInd) *60/Total_flow_rate(1)/2, '--b')
xlabel('Construct Height [mm]')
ylabel('Cell concentration [cells/{\mul}]')
xlim([-0.1, bin_edges_scaled(end)+0.1])
ylim([0,y_max])

cell_conc_app=n_events(Exp.AppInd)*60/Total_flow_rate(1)/2;

figure()
plot(1:numel(Exp.AppInd),cell_conc_app,'.r','MarkerSize',10)
hold on
plot(cell_setpoint(Exp.AppInd) *60/Total_flow_rate(1)/2, '--b')
ylim([0,450])
xlim([1,numel(Exp.AppInd)])
xlabel('Time [s]')
ylabel('Instant cell concentration [cells/{\mul}]')
set(gca, 'XAxisLocation', 'top')
set(gca, 'TickDir', 'in')


figure()
plot(main_flow_rate(Exp.AppInd))
hold on
yline(Total_flow_rate(1), '--r')
xlabel('Time [s]')
ylabel('Flow rate [{\mul}/min]')
legend('Sample Flow rate', 'Total Flow rate')
