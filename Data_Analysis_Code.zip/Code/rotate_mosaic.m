function [image_rot, rotation_mask]=rotate_mosaic(image, rot_angle)

mosaic_mask=ones(size(image));

image_rot=imrotate(image, rot_angle);

rotation_mask=imrotate(mosaic_mask, rot_angle);

figure()
subplot(1,2,1)
imshow(rotation_mask)

subplot(1,2,2)
imshow(image_rot)

end





