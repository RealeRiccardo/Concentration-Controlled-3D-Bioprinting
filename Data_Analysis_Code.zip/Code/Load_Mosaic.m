function [Exp, total_image]=Load_Mosaic(Exp)

if exist ([Exp.pathname  'Mosaic_save.mat'])
    load([Exp.pathname  'Mosaic_save.mat'])
else
    % % % DETECT FILES IN FOLDER
    files=dir([Exp.pathname  '*_01.oif.files']);
    Exp.n_files=numel(files);

    % % % LOOP ON FILES
    for iii=1:Exp.n_files

        iii

        % % % IDENTIIFY Z-STACK FILES
        fullname=[Exp.pathname files(iii).name  '\*C001*.tif'];
        z_stack=dir(fullname);
        Exp.n_stack=numel(z_stack);

        % % % READ IMAGES
        if Exp.n_stack>0

            Voxel=Exp.FOV*Exp.n_stack*0.015; % [mm3]

            for jjj=1:Exp.n_stack

                I(:,:,jjj)=imread([z_stack(jjj).folder '\' z_stack(jjj).name]);

                % figure()
                % imagesc(I(:,:,jjj))
                % pause()
            end

            % % % COLLAPSE Z-STACK
            collapsed_I(:,:,iii)=sum(I,3)/size(I,3);


            % figure()
            % imagesc(collapsed_I(:,:,iii))
            % pause()
        end
    end

    % % % MOSAIC IMAGES INTO SINGLE IMAGE
    image_pixel_size=size(collapsed_I,1);
    total_image_size=image_pixel_size*Exp.Panel_size;
    total_image=zeros(total_image_size);

    for kkk=1:Exp.Panel_size(1)
        for zzz=1:Exp.Panel_size(2)
            total_image( (1:image_pixel_size) + (kkk-1)*image_pixel_size,...
                (1:image_pixel_size) + (zzz-1)*image_pixel_size)=...
                collapsed_I(:,:, Exp.Mos_ind(kkk, zzz));
        end
    end
    % [xx,yy]=meshgrid(1:total_image_size(2),1:total_image_size(1));
    % figure;mesh(xx,yy,total_image);

    save([Exp.pathname  'Mosaic_save.mat'])

end


end