classdef Cell_counter_v2 < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                       matlab.ui.Figure
        Pump2FlowRateulminEditField    matlab.ui.control.NumericEditField
        Pump2FlowRateulminLabel        matlab.ui.control.Label
        FilenameEditField              matlab.ui.control.EditField
        FilenameEditFieldLabel         matlab.ui.control.Label
        TotalFlowRateEditField         matlab.ui.control.NumericEditField
        TotalFlowRateEditFieldLabel    matlab.ui.control.Label
        DATASAVESwitch                 matlab.ui.control.ToggleSwitch
        DATASAVESwitchLabel            matlab.ui.control.Label
        Pump2SheathSwitch              matlab.ui.control.Switch
        Pump2SheathSwitchLabel         matlab.ui.control.Label
        SignalFilteringSwitch          matlab.ui.control.Switch
        SignalFilteringSwitchLabel     matlab.ui.control.Label
        ResetPlotsButton               matlab.ui.control.Button
        MeasuredThroughputCellsSecondEditField  matlab.ui.control.NumericEditField
        MeasuredThroughputCellsSecondEditFieldLabel  matlab.ui.control.Label
        Pump1SampleSwitch              matlab.ui.control.Switch
        Pump1SampleSwitchLabel         matlab.ui.control.Label
        Pump1FlowRateulminEditField    matlab.ui.control.NumericEditField
        Pump1FlowRateulminLabel        matlab.ui.control.Label
        DesiredThroughputCellsSecondEditField  matlab.ui.control.NumericEditField
        DesiredThroughputCellsSecondEditFieldLabel  matlab.ui.control.Label
        PumpFeedbackControlSwitch      matlab.ui.control.ToggleSwitch
        PUMPFEEDBACKCONTROLLabel       matlab.ui.control.Label
        PeakThresholdVEditField        matlab.ui.control.NumericEditField
        PeakThresholdVEditFieldLabel   matlab.ui.control.Label
        LowPassFreqHzEditField         matlab.ui.control.NumericEditField
        LowPassFreqHzEditFieldLabel    matlab.ui.control.Label
        RealTimeSignalPlotButton       matlab.ui.control.StateButton
        ScanDurationsEditField         matlab.ui.control.NumericEditField
        ScanDurationsEditFieldLabel    matlab.ui.control.Label
        SamplingRatekHzEditField       matlab.ui.control.NumericEditField
        SamplingRatekHzEditFieldLabel  matlab.ui.control.Label
        SignalAcquisitionSwitch        matlab.ui.control.Switch
        SignalAcquisitionSwitchLabel   matlab.ui.control.Label
        Throughput_plot                matlab.ui.control.UIAxes
        Flowrate_plot                  matlab.ui.control.UIAxes
        Signal_plot                    matlab.ui.control.UIAxes
    end

    properties (Access = private)

        % Initialize DAQ
        dq = daq("ni");

        % Initialize counter
        block_counter=1;

        % Initialize PUMPS
        pump_main=serialport('COM4', 115200);
        pump_sheath=serialport('COM5', 115200);

    end

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)

            % Initialize DAQ
            addinput(app.dq, 'Dev1', 'ai0', 'Voltage')

            % Initialize PUMP1 (Sample)
            configureTerminator(app.pump_main,'CR/LF')
            writeline(app.pump_main,'nvram none')

            % Initialize PUMP2 (Sheath)
            configureTerminator(app.pump_sheath,'CR/LF')
            writeline(app.pump_sheath,'nvram none')

        end

        % Value changed function: SignalAcquisitionSwitch
        function SignalAcquisitionSwitchValueChanged(app, event)

            while strcmp(app.SignalAcquisitionSwitch.Value,'On')
                % Scan DAQ
                app.dq.Rate  = app.SamplingRatekHzEditField.Value*1000;
                data = read(app.dq, seconds(app.ScanDurationsEditField.Value));

                % Unit conversion
                Q_m3s=app.Pump1FlowRateulminEditField.Value*1.66e-11; %From [ul/min] to [m3/s]
                A_m2=40*25*1e-12;     %From [um2]    to [m2]
                % Compute velocity
                velocity=Q_m3s/A_m2;

                % Estimate crossing time
                L=200e-6; % [m]
                cross_time=L/velocity;
                half_window=floor(2*app.dq.Rate*cross_time);

                % Segmentation
                if strcmp(app.SignalFilteringSwitch.Value,'On')
                    signal_filt=lowpass(data.Dev1_ai0,app.LowPassFreqHzEditField.Value,app.dq.Rate);
                else
                    signal_filt=data.Dev1_ai0;
                end
                samples=3:(length(signal_filt)-2);
                [peak_int ,peak_coord_samp]=findpeaks(signal_filt(3:end-2),samples,...
                    'MinPeakDistance',half_window,'MinPeakHeight',app.PeakThresholdVEditField.Value);

                % Real time events plot
                if app.RealTimeSignalPlotButton.Value
                    cla(app.Signal_plot)
                    hold(app.Signal_plot,'on');
                    plot(app.Signal_plot,data.Time,signal_filt);
                    scatter(app.Signal_plot,data.Time(peak_coord_samp), peak_int)
                end

                % Store relevant variables in vectors
                n_events(app.block_counter)=size(peak_int,1)/app.ScanDurationsEditField.Value;
                app.MeasuredThroughputCellsSecondEditField.Value=n_events(app.block_counter);
                cell_setpoint(app.block_counter)=app.DesiredThroughputCellsSecondEditField.Value;

                % Adjust flow rate
                if strcmp(app.PumpFeedbackControlSwitch.Value,'On')

                    % Estimate concentration
                    cell_conc=n_events(app.block_counter)/app.Pump1FlowRateulminEditField.Value;

                    % Compute ideal sample flowrate
                    suggested_flow_rate=app.DesiredThroughputCellsSecondEditField.Value/cell_conc;

                    % Adjust main flow rate with hard cap
                    if suggested_flow_rate>=app.TotalFlowRateEditField.Value
                        app.Pump1FlowRateulminEditField.Value=app.TotalFlowRateEditField.Value;
                        app.Pump1FlowRateulminEditField.BackgroundColor=[1,0,0];
                    else
                        app.Pump1FlowRateulminEditField.Value=suggested_flow_rate;
                        app.Pump1FlowRateulminEditField.BackgroundColor=[1,1,1];
                    end
                    writeline(app.pump_main,['irate ' num2str(app.Pump1FlowRateulminEditField.Value) ' u/m'])
                    % Verify pump status
                    writeread(app.pump_main,'irate')

                    if strcmp(app.Pump2SheathSwitch.Value,'On')
                        app.Pump2FlowRateulminEditField.Value=app.TotalFlowRateEditField.Value-app.Pump1FlowRateulminEditField.Value;
                        % Adjust sheath flow rate
                        writeline(app.pump_sheath,['irate ' num2str(app.Pump2FlowRateulminEditField.Value) ' u/m'])
                        % Verify pump status
                        writeread(app.pump_sheath,'irate')
                    end

                end

                % Store relevant variables in vectors
                main_flow_rate(app.block_counter)=app.Pump1FlowRateulminEditField.Value;
                total_flow_rate(app.block_counter)=app.TotalFlowRateEditField.Value;
                sheath_flow_rate(app.block_counter)=app.Pump2FlowRateulminEditField.Value;

                
                if strcmp(app.PumpFeedbackControlSwitch.Value,'On')
                    suggested_flow_rate_LOG(app.block_counter)=suggested_flow_rate;
                end

                % Throughput plot
                cla(app.Throughput_plot)
                hold(app.Throughput_plot,'on');
                scatter(app.Throughput_plot,1:app.block_counter, n_events(1:app.block_counter),'r','filled')
                if strcmp(app.PumpFeedbackControlSwitch.Value,'On')
                    plot(app.Throughput_plot,1:app.block_counter,cell_setpoint(1:app.block_counter))
                end

                % Flowrate plot
                cla(app.Flowrate_plot)
                hold(app.Flowrate_plot,'on');
                plot(app.Flowrate_plot, 1:app.block_counter, main_flow_rate(1:app.block_counter),'g', 'LineWidth', 1)
                if strcmp(app.Pump2SheathSwitch.Value,'On')
                    plot(app.Flowrate_plot, 1:app.block_counter, sheath_flow_rate(1:app.block_counter),'b', 'LineWidth', 1)
                end
                if strcmp(app.PumpFeedbackControlSwitch.Value,'On')
                    plot(app.Flowrate_plot, 1:app.block_counter, total_flow_rate(1:app.block_counter),'k')
                    plot(app.Flowrate_plot, 1:app.block_counter, suggested_flow_rate_LOG(1:app.block_counter),'r-.')
                end
                % Log data
                if strcmp(app.DATASAVESwitch.Value,'On')
                  
                    signal_unfilt_save{app.block_counter}=data.Dev1_ai0;
                    signal_filt_save{app.block_counter}=signal_filt;

                    % Adjust flow rate
                    if strcmp(app.PumpFeedbackControlSwitch.Value,'On')
                        if strcmp(app.Pump2SheathSwitch.Value,'On')
                            save([app.FilenameEditField.Value '.mat'], 'n_events', 'cell_setpoint', ...
                                'main_flow_rate', 'total_flow_rate', 'suggested_flow_rate_LOG', 'sheath_flow_rate',...
                                'signal_unfilt_save', 'signal_filt_save' )
                        else
                            save([app.FilenameEditField.Value '.mat'], 'n_events', 'cell_setpoint', ...
                                'main_flow_rate', 'total_flow_rate', 'suggested_flow_rate_LOG',...
                                'signal_unfilt_save', 'signal_filt_save' )
                        end
                    else
                        save([app.FilenameEditField.Value '.mat'], 'n_events', 'main_flow_rate',...
                            'signal_unfilt_save', 'signal_filt_save' )
                    end
                end

                % Update block counter
                app.block_counter=app.block_counter+1;
            end
        end

        % Value changed function: PumpFeedbackControlSwitch
        function PumpFeedbackControlSwitchValueChanged(app, event)

            if strcmp(app.PumpFeedbackControlSwitch.Value,'On')
                % Disable manual flow rate control
                app.Pump1FlowRateulminEditField.Editable='Off';
                app.Pump1FlowRateulminEditField.BackgroundColor=[0.64,0.08,0.18];
                app.Pump2FlowRateulminEditField.Editable='Off';
                app.Pump2FlowRateulminEditField.BackgroundColor=[0.64,0.08,0.18];
                % Enable desired cell throughput
                app.DesiredThroughputCellsSecondEditField.Enable='On';
                app.DesiredThroughputCellsSecondEditField.Editable='On';
                app.Pump2FlowRateulminEditField.BackgroundColor=[1,1,1];
            else
                % Enable manual flow rate control
                app.Pump1FlowRateulminEditField.Editable='On';
                app.Pump1FlowRateulminEditField.BackgroundColor=[1,1,1];
                app.Pump2FlowRateulminEditField.Editable='On';
                app.Pump2FlowRateulminEditField.BackgroundColor=[1,1,1];
                % Disable desired cell throughput
                app.DesiredThroughputCellsSecondEditField.Enable='Off';
                app.DesiredThroughputCellsSecondEditField.Editable='Off';
                app.Pump2FlowRateulminEditField.BackgroundColor=[0.64,0.08,0.18];
            end

            % Re-initialize counter
            app.block_counter=1;

        end

        % Value changed function: Pump1SampleSwitch
        function Pump1SampleSwitchValueChanged(app, event)
            % Set flowrate
            writeline(app.pump_main,['irate ' num2str(app.Pump1FlowRateulminEditField.Value) ' u/m'])

            % Start/Stop pump
            if strcmp(app.Pump1SampleSwitch.Value,'On')
                writeline(app.pump_main,'run')
            else
                writeline(app.pump_main,'stop')
            end

            % Verify pump status
            writeread(app.pump_main,'irate')

            % Re-initialize counter
            app.block_counter=1;
        end

        % Value changed function: Pump1FlowRateulminEditField
        function Pump1FlowRateulminEditFieldValueChanged(app, event)

            if strcmp(app.Pump1SampleSwitch.Value,'On')
                
                % Set flowrate
                writeline(app.pump_main,['irate ' num2str(app.Pump1FlowRateulminEditField.Value) ' u/m'])

                % Verify pump status
                writeread(app.pump_main,'irate')

            end
        end

        % Value changed function: Pump2SheathSwitch
        function Pump2SheathSwitchValueChanged(app, event)
            % Set flowrate
            writeline(app.pump_sheath,['irate ' num2str(app.Pump2FlowRateulminEditField.Value) ' u/m'])

            % Start/Stop pump
            if strcmp(app.Pump2SheathSwitch.Value,'On')
                writeline(app.pump_sheath,'run')
            else
                writeline(app.pump_sheath,'stop')
            end

            % Verify pump status
            writeread(app.pump_sheath,'irate')

            % Re-initialize counter
            app.block_counter=1;
        end

        % Value changed function: Pump2FlowRateulminEditField
        function Pump2FlowRateulminEditFieldValueChanged(app, event)
            
            if strcmp(app.Pump2SheathSwitch.Value,'On')
                
                % Set flowrate
                writeline(app.pump_sheath,['irate ' num2str(app.Pump2FlowRateulminEditField.Value) ' u/m'])

                % Verify pump status
                writeread(app.pump_sheath,'irate')
            end

        end

        % Button pushed function: ResetPlotsButton
        function ResetPlotsButtonPushed(app, event)
            % Re-initialize counter
            app.block_counter=1;
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 1002 733];
            app.UIFigure.Name = 'MATLAB App';

            % Create Signal_plot
            app.Signal_plot = uiaxes(app.UIFigure);
            xlabel(app.Signal_plot, 'Samples')
            ylabel(app.Signal_plot, 'Signal')
            zlabel(app.Signal_plot, 'Z')
            app.Signal_plot.Position = [12 61 319 252];

            % Create Flowrate_plot
            app.Flowrate_plot = uiaxes(app.UIFigure);
            xlabel(app.Flowrate_plot, 'Block')
            ylabel(app.Flowrate_plot, 'Flow Rate [ul/min]')
            zlabel(app.Flowrate_plot, 'Z')
            app.Flowrate_plot.Position = [660 61 327 252];

            % Create Throughput_plot
            app.Throughput_plot = uiaxes(app.UIFigure);
            xlabel(app.Throughput_plot, 'Block')
            ylabel(app.Throughput_plot, 'Throughput [Cells/Second]')
            zlabel(app.Throughput_plot, 'Z')
            app.Throughput_plot.Position = [338 61 313 252];

            % Create SignalAcquisitionSwitchLabel
            app.SignalAcquisitionSwitchLabel = uilabel(app.UIFigure);
            app.SignalAcquisitionSwitchLabel.HorizontalAlignment = 'center';
            app.SignalAcquisitionSwitchLabel.WordWrap = 'on';
            app.SignalAcquisitionSwitchLabel.FontSize = 20;
            app.SignalAcquisitionSwitchLabel.FontWeight = 'bold';
            app.SignalAcquisitionSwitchLabel.Position = [59 636 167 60];
            app.SignalAcquisitionSwitchLabel.Text = 'Signal Acquisition';

            % Create SignalAcquisitionSwitch
            app.SignalAcquisitionSwitch = uiswitch(app.UIFigure, 'slider');
            app.SignalAcquisitionSwitch.ValueChangedFcn = createCallbackFcn(app, @SignalAcquisitionSwitchValueChanged, true);
            app.SignalAcquisitionSwitch.FontSize = 18;
            app.SignalAcquisitionSwitch.FontWeight = 'bold';
            app.SignalAcquisitionSwitch.Position = [96 592 101 45];

            % Create SamplingRatekHzEditFieldLabel
            app.SamplingRatekHzEditFieldLabel = uilabel(app.UIFigure);
            app.SamplingRatekHzEditFieldLabel.HorizontalAlignment = 'right';
            app.SamplingRatekHzEditFieldLabel.Position = [49 549 115 22];
            app.SamplingRatekHzEditFieldLabel.Text = 'Sampling Rate [kHz]';

            % Create SamplingRatekHzEditField
            app.SamplingRatekHzEditField = uieditfield(app.UIFigure, 'numeric');
            app.SamplingRatekHzEditField.Position = [177 549 46 22];
            app.SamplingRatekHzEditField.Value = 40;

            % Create ScanDurationsEditFieldLabel
            app.ScanDurationsEditFieldLabel = uilabel(app.UIFigure);
            app.ScanDurationsEditFieldLabel.HorizontalAlignment = 'right';
            app.ScanDurationsEditFieldLabel.Position = [67 517 98 22];
            app.ScanDurationsEditFieldLabel.Text = 'Scan Duration [s]';

            % Create ScanDurationsEditField
            app.ScanDurationsEditField = uieditfield(app.UIFigure, 'numeric');
            app.ScanDurationsEditField.Position = [178 517 46 22];
            app.ScanDurationsEditField.Value = 1;

            % Create RealTimeSignalPlotButton
            app.RealTimeSignalPlotButton = uibutton(app.UIFigure, 'state');
            app.RealTimeSignalPlotButton.Text = 'Real Time Signal Plot';
            app.RealTimeSignalPlotButton.Position = [237 23 131 22];
            app.RealTimeSignalPlotButton.Value = true;

            % Create LowPassFreqHzEditFieldLabel
            app.LowPassFreqHzEditFieldLabel = uilabel(app.UIFigure);
            app.LowPassFreqHzEditFieldLabel.HorizontalAlignment = 'right';
            app.LowPassFreqHzEditFieldLabel.Position = [57 399 110 22];
            app.LowPassFreqHzEditFieldLabel.Text = 'Low Pass Freq [Hz]';

            % Create LowPassFreqHzEditField
            app.LowPassFreqHzEditField = uieditfield(app.UIFigure, 'numeric');
            app.LowPassFreqHzEditField.Position = [180 399 46 22];
            app.LowPassFreqHzEditField.Value = 1000000;

            % Create PeakThresholdVEditFieldLabel
            app.PeakThresholdVEditFieldLabel = uilabel(app.UIFigure);
            app.PeakThresholdVEditFieldLabel.HorizontalAlignment = 'right';
            app.PeakThresholdVEditFieldLabel.Position = [57 484 108 22];
            app.PeakThresholdVEditFieldLabel.Text = 'Peak Threshold [V]';

            % Create PeakThresholdVEditField
            app.PeakThresholdVEditField = uieditfield(app.UIFigure, 'numeric');
            app.PeakThresholdVEditField.Position = [178 484 46 22];
            app.PeakThresholdVEditField.Value = 1.6;

            % Create PUMPFEEDBACKCONTROLLabel
            app.PUMPFEEDBACKCONTROLLabel = uilabel(app.UIFigure);
            app.PUMPFEEDBACKCONTROLLabel.FontSize = 18;
            app.PUMPFEEDBACKCONTROLLabel.FontWeight = 'bold';
            app.PUMPFEEDBACKCONTROLLabel.Position = [406 479 214 101];
            app.PUMPFEEDBACKCONTROLLabel.Text = 'Pump Feedback Control';

            % Create PumpFeedbackControlSwitch
            app.PumpFeedbackControlSwitch = uiswitch(app.UIFigure, 'toggle');
            app.PumpFeedbackControlSwitch.ValueChangedFcn = createCallbackFcn(app, @PumpFeedbackControlSwitchValueChanged, true);
            app.PumpFeedbackControlSwitch.FontSize = 16;
            app.PumpFeedbackControlSwitch.FontWeight = 'bold';
            app.PumpFeedbackControlSwitch.Position = [367 495 26 59];

            % Create DesiredThroughputCellsSecondEditFieldLabel
            app.DesiredThroughputCellsSecondEditFieldLabel = uilabel(app.UIFigure);
            app.DesiredThroughputCellsSecondEditFieldLabel.HorizontalAlignment = 'center';
            app.DesiredThroughputCellsSecondEditFieldLabel.WordWrap = 'on';
            app.DesiredThroughputCellsSecondEditFieldLabel.FontSize = 18;
            app.DesiredThroughputCellsSecondEditFieldLabel.FontWeight = 'bold';
            app.DesiredThroughputCellsSecondEditFieldLabel.Position = [423 435 178 59];
            app.DesiredThroughputCellsSecondEditFieldLabel.Text = 'Desired Throughput [Cells/Second]';

            % Create DesiredThroughputCellsSecondEditField
            app.DesiredThroughputCellsSecondEditField = uieditfield(app.UIFigure, 'numeric');
            app.DesiredThroughputCellsSecondEditField.Editable = 'off';
            app.DesiredThroughputCellsSecondEditField.HorizontalAlignment = 'center';
            app.DesiredThroughputCellsSecondEditField.FontSize = 20;
            app.DesiredThroughputCellsSecondEditField.FontWeight = 'bold';
            app.DesiredThroughputCellsSecondEditField.Enable = 'off';
            app.DesiredThroughputCellsSecondEditField.Position = [467 399 90 37];
            app.DesiredThroughputCellsSecondEditField.Value = 5;

            % Create Pump1FlowRateulminLabel
            app.Pump1FlowRateulminLabel = uilabel(app.UIFigure);
            app.Pump1FlowRateulminLabel.HorizontalAlignment = 'center';
            app.Pump1FlowRateulminLabel.WordWrap = 'on';
            app.Pump1FlowRateulminLabel.FontSize = 14;
            app.Pump1FlowRateulminLabel.FontWeight = 'bold';
            app.Pump1FlowRateulminLabel.Position = [720 611 228 57];
            app.Pump1FlowRateulminLabel.Text = {'Pump 1 Flow Rate'; ' [ul/min]'};

            % Create Pump1FlowRateulminEditField
            app.Pump1FlowRateulminEditField = uieditfield(app.UIFigure, 'numeric');
            app.Pump1FlowRateulminEditField.ValueChangedFcn = createCallbackFcn(app, @Pump1FlowRateulminEditFieldValueChanged, true);
            app.Pump1FlowRateulminEditField.HorizontalAlignment = 'center';
            app.Pump1FlowRateulminEditField.FontSize = 18;
            app.Pump1FlowRateulminEditField.Position = [803 592 61 23];
            app.Pump1FlowRateulminEditField.Value = 1;

            % Create Pump1SampleSwitchLabel
            app.Pump1SampleSwitchLabel = uilabel(app.UIFigure);
            app.Pump1SampleSwitchLabel.HorizontalAlignment = 'center';
            app.Pump1SampleSwitchLabel.WordWrap = 'on';
            app.Pump1SampleSwitchLabel.FontSize = 16;
            app.Pump1SampleSwitchLabel.FontWeight = 'bold';
            app.Pump1SampleSwitchLabel.Position = [757 695 144 38];
            app.Pump1SampleSwitchLabel.Text = 'Pump 1 (Sample)';

            % Create Pump1SampleSwitch
            app.Pump1SampleSwitch = uiswitch(app.UIFigure, 'slider');
            app.Pump1SampleSwitch.ValueChangedFcn = createCallbackFcn(app, @Pump1SampleSwitchValueChanged, true);
            app.Pump1SampleSwitch.FontSize = 18;
            app.Pump1SampleSwitch.FontWeight = 'bold';
            app.Pump1SampleSwitch.Position = [794 664 72 32];

            % Create MeasuredThroughputCellsSecondEditFieldLabel
            app.MeasuredThroughputCellsSecondEditFieldLabel = uilabel(app.UIFigure);
            app.MeasuredThroughputCellsSecondEditFieldLabel.HorizontalAlignment = 'center';
            app.MeasuredThroughputCellsSecondEditFieldLabel.WordWrap = 'on';
            app.MeasuredThroughputCellsSecondEditFieldLabel.FontSize = 18;
            app.MeasuredThroughputCellsSecondEditFieldLabel.FontWeight = 'bold';
            app.MeasuredThroughputCellsSecondEditFieldLabel.Position = [418 625 202 63];
            app.MeasuredThroughputCellsSecondEditFieldLabel.Text = 'Measured Throughput [Cells/Second]';

            % Create MeasuredThroughputCellsSecondEditField
            app.MeasuredThroughputCellsSecondEditField = uieditfield(app.UIFigure, 'numeric');
            app.MeasuredThroughputCellsSecondEditField.HorizontalAlignment = 'center';
            app.MeasuredThroughputCellsSecondEditField.FontSize = 20;
            app.MeasuredThroughputCellsSecondEditField.FontWeight = 'bold';
            app.MeasuredThroughputCellsSecondEditField.Position = [474 591 90 37];

            % Create ResetPlotsButton
            app.ResetPlotsButton = uibutton(app.UIFigure, 'push');
            app.ResetPlotsButton.ButtonPushedFcn = createCallbackFcn(app, @ResetPlotsButtonPushed, true);
            app.ResetPlotsButton.Position = [711 16 97 36];
            app.ResetPlotsButton.Text = 'Reset Plots';

            % Create SignalFilteringSwitchLabel
            app.SignalFilteringSwitchLabel = uilabel(app.UIFigure);
            app.SignalFilteringSwitchLabel.HorizontalAlignment = 'center';
            app.SignalFilteringSwitchLabel.Position = [110 435 85 22];
            app.SignalFilteringSwitchLabel.Text = 'Signal Filtering';

            % Create SignalFilteringSwitch
            app.SignalFilteringSwitch = uiswitch(app.UIFigure, 'slider');
            app.SignalFilteringSwitch.Position = [129 455 45 20];

            % Create Pump2SheathSwitchLabel
            app.Pump2SheathSwitchLabel = uilabel(app.UIFigure);
            app.Pump2SheathSwitchLabel.HorizontalAlignment = 'center';
            app.Pump2SheathSwitchLabel.WordWrap = 'on';
            app.Pump2SheathSwitchLabel.FontSize = 16;
            app.Pump2SheathSwitchLabel.FontWeight = 'bold';
            app.Pump2SheathSwitchLabel.Position = [744 539 162 22];
            app.Pump2SheathSwitchLabel.Text = 'Pump 2 (Sheath)';

            % Create Pump2SheathSwitch
            app.Pump2SheathSwitch = uiswitch(app.UIFigure, 'slider');
            app.Pump2SheathSwitch.ValueChangedFcn = createCallbackFcn(app, @Pump2SheathSwitchValueChanged, true);
            app.Pump2SheathSwitch.FontSize = 18;
            app.Pump2SheathSwitch.FontWeight = 'bold';
            app.Pump2SheathSwitch.Position = [803 507 61 27];

            % Create DATASAVESwitchLabel
            app.DATASAVESwitchLabel = uilabel(app.UIFigure);
            app.DATASAVESwitchLabel.HorizontalAlignment = 'center';
            app.DATASAVESwitchLabel.FontWeight = 'bold';
            app.DATASAVESwitchLabel.Position = [579 34 72 22];
            app.DATASAVESwitchLabel.Text = 'DATASAVE';

            % Create DATASAVESwitch
            app.DATASAVESwitch = uiswitch(app.UIFigure, 'toggle');
            app.DATASAVESwitch.Position = [650 28 20 45];

            % Create TotalFlowRateEditFieldLabel
            app.TotalFlowRateEditFieldLabel = uilabel(app.UIFigure);
            app.TotalFlowRateEditFieldLabel.HorizontalAlignment = 'center';
            app.TotalFlowRateEditFieldLabel.WordWrap = 'on';
            app.TotalFlowRateEditFieldLabel.FontSize = 18;
            app.TotalFlowRateEditFieldLabel.FontWeight = 'bold';
            app.TotalFlowRateEditFieldLabel.Position = [741 374 178 23];
            app.TotalFlowRateEditFieldLabel.Text = 'Total Flow Rate';

            % Create TotalFlowRateEditField
            app.TotalFlowRateEditField = uieditfield(app.UIFigure, 'numeric');
            app.TotalFlowRateEditField.HorizontalAlignment = 'center';
            app.TotalFlowRateEditField.FontSize = 20;
            app.TotalFlowRateEditField.FontWeight = 'bold';
            app.TotalFlowRateEditField.Position = [786 337 85 37];
            app.TotalFlowRateEditField.Value = 5;

            % Create FilenameEditFieldLabel
            app.FilenameEditFieldLabel = uilabel(app.UIFigure);
            app.FilenameEditFieldLabel.HorizontalAlignment = 'right';
            app.FilenameEditFieldLabel.Position = [440 34 55 22];
            app.FilenameEditFieldLabel.Text = 'Filename';

            % Create FilenameEditField
            app.FilenameEditField = uieditfield(app.UIFigure, 'text');
            app.FilenameEditField.Position = [423 13 100 22];
            app.FilenameEditField.Value = 'Test';

            % Create Pump2FlowRateulminLabel
            app.Pump2FlowRateulminLabel = uilabel(app.UIFigure);
            app.Pump2FlowRateulminLabel.HorizontalAlignment = 'center';
            app.Pump2FlowRateulminLabel.WordWrap = 'on';
            app.Pump2FlowRateulminLabel.FontSize = 14;
            app.Pump2FlowRateulminLabel.FontWeight = 'bold';
            app.Pump2FlowRateulminLabel.Position = [716 454 228 57];
            app.Pump2FlowRateulminLabel.Text = {'Pump 2 Flow Rate'; ' [ul/min]'};

            % Create Pump2FlowRateulminEditField
            app.Pump2FlowRateulminEditField = uieditfield(app.UIFigure, 'numeric');
            app.Pump2FlowRateulminEditField.ValueChangedFcn = createCallbackFcn(app, @Pump2FlowRateulminEditFieldValueChanged, true);
            app.Pump2FlowRateulminEditField.HorizontalAlignment = 'center';
            app.Pump2FlowRateulminEditField.FontSize = 18;
            app.Pump2FlowRateulminEditField.Position = [799 435 61 23];

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = Cell_counter_v2

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end